Run these examples from the root directory of pycparser
